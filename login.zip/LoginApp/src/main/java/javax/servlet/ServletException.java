package javax.servlet;

public class ServletException {

}
