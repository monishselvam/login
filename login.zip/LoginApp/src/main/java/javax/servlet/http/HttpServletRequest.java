package javax.servlet.http;

public class HttpServletRequest {

}
